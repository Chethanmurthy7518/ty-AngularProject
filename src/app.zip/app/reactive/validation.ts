import {FormGroup} from "@angular/forms"

export function customValidaators(data:FormGroup){
    // const pass = data.value.
}