import { Component } from "@angular/core";

@Component({
    selector: "basic",
    template:"<h1>Welcome to Angular</h1>",
    styles:["h1{color:red}"]
})
export class Basic{
    
}

